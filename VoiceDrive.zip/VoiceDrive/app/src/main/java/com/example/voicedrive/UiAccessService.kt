package com.example.voicedrive

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** YouTube画面の操作(広告スキップ・動画タップ)。画面構造に依存するため要調整。 */
class UiAccessService : AccessibilityService() {
    companion object {
        @Volatile var instance: UiAccessService? = null
        var autoSkip = true
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (autoSkip && e?.packageName?.toString() == "com.google.android.youtube") skipAd()
    }

    fun skipAd(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/skip_ad_button").firstOrNull()
            ?: root.findAccessibilityNodeInfosByText("スキップ").firstOrNull()
            ?: root.findAccessibilityNodeInfosByText("Skip").firstOrNull()
        return click(node)
    }

    /** 検索結果のn番目の動画をタップ(説明文に「秒」を含む要素を動画とみなす簡易判定) */
    fun tapVideo(n: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val list = ArrayList<AccessibilityNodeInfo>()
        fun walk(x: AccessibilityNodeInfo?) {
            x ?: return
            if (x.isClickable && x.contentDescription?.contains("秒") == true) list.add(x)
            for (i in 0 until x.childCount) walk(x.getChild(i))
        }
        walk(root)
        return click(list.getOrNull(n - 1))
    }

    private fun click(n: AccessibilityNodeInfo?): Boolean {
        var x = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }
}
