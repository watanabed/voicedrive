package com.example.voicedrive

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** LINE通知を読み上げ用に取得し、通知のインライン返信(RemoteInput)で返信する。 */
class LineListener : NotificationListenerService() {
    companion object {
        var onMessage: ((String, String) -> Unit)? = null
        var last: String? = null
        private var action: Notification.Action? = null

        fun reply(ctx: Context, text: String): Boolean {
            val a = action ?: return false
            val inputs = a.remoteInputs ?: return false
            val ri = inputs.firstOrNull() ?: return false
            val data = Intent()
            RemoteInput.addResultsToIntent(inputs, data, Bundle().apply { putCharSequence(ri.resultKey, text) })
            return try { a.actionIntent.send(ctx, 0, data); true } catch (e: Exception) { false }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "jp.naver.line.android") return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        action = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        last = title
        onMessage?.invoke(title, text)
    }
}
