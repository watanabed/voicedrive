package com.example.voicedrive

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

/** 常時待機の音声認識。「ドライブ、○○」と呼びかけた時だけコマンドとして実行する。 */
class VoiceService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private val WAKE = "ドライブ"
    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private var ttsReady = false
    private var speaking = false
    private var replyMode = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("v", "音声操作", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "v").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("VoiceDrive 待機中").setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
        tts = TextToSpeech(this, this)
        LineListener.onMessage = { from, text -> say("${from}さんから。$text。返信は、ドライブ、返信、です。") }
    }

    override fun onDestroy() {
        LineListener.onMessage = null
        sr?.destroy(); tts.shutdown()
        super.onDestroy()
    }

    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) { listen(); return }
        tts.setLanguage(Locale.JAPAN)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { speaking = false; listen() } }
            override fun onError(id: String?) { main.post { speaking = false; listen() } }
        })
        ttsReady = true
        say("音声操作を開始します")
    }

    /** 発話する。戻り値 true = 発話中(終了後に自動で聞き取り再開) */
    private fun say(t: String): Boolean {
        if (!ttsReady) return false
        speaking = true
        sr?.cancel()
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
        return true
    }

    private fun listen() {
        if (speaking) return
        sr?.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ja-JP")
        )
    }

    override fun onResults(r: Bundle?) {
        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (t == null || !handle(t)) listen()
    }

    override fun onError(e: Int) {
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
        main.postDelayed({ listen() }, 300)
    }

    private fun handle(raw: String): Boolean {
        if (replyMode) {
            replyMode = false
            if (raw.contains("キャンセル")) return say("やめました")
            return say(if (LineListener.reply(this, raw.trim())) "送信しました" else "返信できませんでした")
        }
        val n = raw.replace(" ", "").replace("　", "").lowercase()
            .replace("drive", WAKE).replace("ユーチューブ", "youtube")
        if (!n.contains(WAKE)) return false
        val t = n.substringAfter(WAKE).trimStart('、', ',')
        return when {
            t.startsWith("返信") -> {
                val body = t.removePrefix("返信").trimStart('、', ',')
                when {
                    LineListener.last == null -> say("返信できる通知がありません")
                    body.isEmpty() -> { replyMode = true; say("返信内容をどうぞ") }
                    else -> say(if (LineListener.reply(this, body)) "送信しました" else "返信できませんでした")
                }
            }
            (t.contains("line") || t.contains("ライン")) && t.contains("開") -> {
                open(packageManager.getLaunchIntentForPackage("jp.naver.line.android")); say("LINEを開きます")
            }
            t.contains("youtube") && t.contains("検索") -> {
                val q = t.replace("youtube", "").replace(Regex("(を)?検索(して(ください)?)?"), "")
                    .removePrefix("で").trim()
                val i = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                    .setPackage("com.google.android.youtube")
                if (open(i)) say("${q}を検索します") else say("YouTubeを開けません")
            }
            t.contains("スキップ") ->
                if (UiAccessService.instance?.skipAd() == true) false else say("スキップできません")
            t.contains("番目") || t.contains("最初") -> {
                val k = Regex("(\\d)番目").find(t)?.groupValues?.get(1)?.toInt() ?: 1
                if (UiAccessService.instance?.tapVideo(k) == true) false else say("動画が見つかりません")
            }
            t.contains("一時停止") || t.contains("止めて") -> key(KeyEvent.KEYCODE_MEDIA_PAUSE)
            t.contains("再生") -> key(KeyEvent.KEYCODE_MEDIA_PLAY)
            t.contains("次") -> key(KeyEvent.KEYCODE_MEDIA_NEXT)
            t.contains("前") -> key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            t.contains("終了") -> { stopSelf(); false }
            else -> false
        }
    }

    private fun open(i: Intent?) =
        runCatching { startActivity(i!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess

    private fun key(code: Int): Boolean {
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return false
    }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(b: Bundle?) {}
    override fun onEvent(t: Int, b: Bundle?) {}
}
