package com.example.voicedrive

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        col.addView(TextView(this).apply { text = "VoiceDrive:上から順に設定"; textSize = 18f })
        fun btn(label: String, go: () -> Unit) =
            col.addView(Button(this).apply { text = label; setOnClickListener { go() } })
        btn("① 権限(マイク・通知)") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("② 他アプリの上に表示を許可") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("③ ユーザー補助をON") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("④ 通知アクセスをON") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("⑤ 開始") { ContextCompat.startForegroundService(this, Intent(this, VoiceService::class.java)) }
        btn("停止") { stopService(Intent(this, VoiceService::class.java)) }
        setContentView(col)
    }
}
